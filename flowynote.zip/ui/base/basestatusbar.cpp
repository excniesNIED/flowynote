#include "basestatusbar.h"

BaseStatusBar::BaseStatusBar(QWidget *parent) :
    QStatusBar(parent)
{
}
