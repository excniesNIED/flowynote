<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en">
<context>
    <name>QObject</name>
    <message>
        <location filename="include/transnames.h" line="9"/>
        <source>undefine</source>
        <oldsource>*undefine</oldsource>
        <translatorcomment>未定义的文件</translatorcomment>
        <translation type="unfinished">未定义</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="19"/>
        <source>Editor View</source>
        <translatorcomment>查看Markdown编辑器</translatorcomment>
        <translation type="unfinished">编辑器视图</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="20"/>
        <source>Preview View</source>
        <translatorcomment>预览Markdown转换后的HTML</translatorcomment>
        <translation type="unfinished">预览视图</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="21"/>
        <source>Double View</source>
        <translatorcomment>同时显示markdown和预览</translatorcomment>
        <translation type="unfinished">双栏编辑</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="22"/>
        <source>Publish Post</source>
        <translatorcomment>发布文章</translatorcomment>
        <translation type="unfinished">发布文章</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="23"/>
        <source>Find</source>
        <translatorcomment>查找</translatorcomment>
        <translation type="unfinished">查找</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="24"/>
        <source>Print</source>
        <translatorcomment>打印</translatorcomment>
        <translation type="unfinished">打印</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="25"/>
        <location filename="include/transnames.h" line="62"/>
        <source>Open</source>
        <translatorcomment>打开文件</translatorcomment>
        <translation type="unfinished">打开文件</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="26"/>
        <source>Save</source>
        <translatorcomment>保存文件</translatorcomment>
        <translation type="unfinished">保存文件</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="27"/>
        <source>Save As</source>
        <translatorcomment>另存为</translatorcomment>
        <translation type="unfinished">另存为</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="28"/>
        <source>Save To Html</source>
        <translatorcomment>另存为HTML</translatorcomment>
        <translation type="unfinished">导出为HTML</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="29"/>
        <source>Sync To Cloud</source>
        <translatorcomment>同步到云端</translatorcomment>
        <translation type="unfinished">同步到云端</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="30"/>
        <source>Set Your Account</source>
        <translatorcomment>设置您的账户</translatorcomment>
        <translation type="unfinished">设置您的账户</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="31"/>
        <source>Setting</source>
        <translatorcomment>设置</translatorcomment>
        <translation type="unfinished">设置</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="32"/>
        <source>About</source>
        <translatorcomment>关于</translatorcomment>
        <translation type="unfinished">关于</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="33"/>
        <source>Feed Back</source>
        <translatorcomment>反馈</translatorcomment>
        <translation type="unfinished">反馈</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="34"/>
        <source>Help</source>
        <translatorcomment>帮助</translatorcomment>
        <translation type="unfinished">帮助</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="35"/>
        <source>Exit</source>
        <translatorcomment>退出</translatorcomment>
        <translation type="unfinished">退出</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="40"/>
        <source>Ctrl+Alt+E</source>
        <translatorcomment>Ctrl+Alt+E</translatorcomment>
        <translation type="unfinished">Ctrl+Alt+E</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="41"/>
        <source>Ctrl+Alt+P</source>
        <translatorcomment>Ctrl+Alt+P</translatorcomment>
        <translation type="unfinished">Ctrl+Alt+P</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="42"/>
        <source>Ctrl+Alt+D</source>
        <translatorcomment>Ctrl+Alt+D</translatorcomment>
        <translation type="unfinished">Ctrl+Alt+D</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="43"/>
        <source>Ctrl+Alt+T</source>
        <translatorcomment>Ctrl+Alt+T</translatorcomment>
        <translation type="unfinished">Ctrl+Alt+T</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="44"/>
        <source>Ctrl+F</source>
        <translatorcomment>Ctrl+F</translatorcomment>
        <translation type="unfinished">Ctrl+F</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="45"/>
        <source>Ctrl+P</source>
        <translatorcomment>Ctrl+P</translatorcomment>
        <translation type="unfinished">Ctrl+P</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="46"/>
        <source>Ctrl+O</source>
        <translatorcomment>Ctrl+O</translatorcomment>
        <translation type="unfinished">Ctrl+O</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="47"/>
        <source>Ctrl+S</source>
        <translatorcomment>Ctrl+S</translatorcomment>
        <translation type="unfinished">Ctrl+S</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="48"/>
        <source>Ctrl+H</source>
        <translatorcomment>Ctrl+H</translatorcomment>
        <translation type="unfinished">Ctrl+H</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="49"/>
        <source>Ctrl+Alt+X</source>
        <translatorcomment>Ctrl+Alt+X</translatorcomment>
        <translation type="unfinished">Ctrl+Alt+X</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="54"/>
        <source>Note</source>
        <translatorcomment>警告</translatorcomment>
        <translation type="unfinished">警告</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="55"/>
        <source>Can not create file</source>
        <translatorcomment>无法创建文件</translatorcomment>
        <translation type="unfinished">无法创建文件</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="56"/>
        <source>Save as markdown file</source>
        <translatorcomment>保存成markdown文件</translatorcomment>
        <translation type="unfinished">保存成markdown文件</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="57"/>
        <source>Save as html file</source>
        <translatorcomment>导出为HTML文件</translatorcomment>
        <translation type="unfinished">导出为HTML文件</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="58"/>
        <source>Save as</source>
        <translatorcomment>另存为</translatorcomment>
        <translation type="unfinished">另存为</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="59"/>
        <location filename="include/transnames.h" line="63"/>
        <source>Markdown file(*.md *.markdown)</source>
        <translatorcomment>markdown文件(*.md *.markdown)</translatorcomment>
        <translation type="unfinished">markdown文件(*.md *.markdown)</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="60"/>
        <source>Html file(*.htm *.html)</source>
        <translatorcomment>HTML文件(*.html *.html)</translatorcomment>
        <translation type="unfinished">HTML文件(*.html *.html)</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="61"/>
        <source>All file(*.*)</source>
        <translatorcomment>所有文件(*.*)</translatorcomment>
        <translation type="unfinished">所有文件(*.*)</translation>
    </message>
    <message>
        <location filename="include/transnames.h" line="64"/>
        <source>Do you want to save the current file ?</source>
        <translatorcomment>您想保存当前文件吗？</translatorcomment>
        <translation type="unfinished">您想保存当前文件吗？</translation>
    </message>
</context>
</TS>
